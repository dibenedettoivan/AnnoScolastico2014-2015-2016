
public class Lampadina {
	

}
