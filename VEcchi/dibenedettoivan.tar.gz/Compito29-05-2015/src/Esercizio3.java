
public class Esercizio3 {
	public static void main(String[] args) {
		
		  
		
		
	}

}
