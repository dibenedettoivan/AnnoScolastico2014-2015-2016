import java.util.Scanner;

public class Esercizio1 {

	public static void main(String[] args) {
		//Di Benedetto Ivan
		//3SA
		Scanner in = new Scanner(System.in);
		double t = 1;
		double F = 0;
			while(t != 0){
			System.out.println("Digita la temperatura in gradi Celsius: ");
			t = in.nextDouble();
			F = (9 * (t) / 5) + 32;
			System.out.println(t);
			System.out.println(F);
		}
	}
}
